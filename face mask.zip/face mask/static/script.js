const video = document.getElementById('video');
navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
  video.srcObject = stream;
});

function speak(text) {
  const utter = new SpeechSynthesisUtterance(text);
  window.speechSynthesis.speak(utter);
}

video.addEventListener('play', () => {
  setInterval(() => {
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    canvas.toBlob(blob => {
      const formData = new FormData();
      formData.append("frame", blob);

      fetch('/predict', {
        method: "POST",
        body: formData
      }).then(res => res.json()).then(data => {
        if (data.status === "Mask") {
          speak("Thank you for wearing a mask.");
        } else {
          speak("Please wear a mask.");
        }
      });
    }, 'image/jpeg');
  }, 3000); // Every 3 seconds
});
