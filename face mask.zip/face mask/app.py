from flask import Flask, render_template, request, jsonify
from tensorflow.keras.models import load_model
import cv2
import numpy as np
from PIL import Image
import io

app = Flask(__name__)
model = load_model("mask_detector_model.h5")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    file = request.files['frame']
    img = Image.open(io.BytesIO(file.read()))
    img = img.resize((224, 224))  # depending on your model input
    img = np.array(img) / 255.0
    img = np.expand_dims(img, axis=0)

    prediction = model.predict(img)
    label = "Mask" if prediction[0][0] < 0.5 else "No Mask"
    return jsonify({"status": label})

if __name__ == "__main__":
    app.run(debug=True)
